function_questions = {1: "What function returns the value of an attribute?",
                2: "Does counter() returns the current value of the named counter? true or false",
                3: "Does max() set the smallest value from a list as the property value? true or false",
                4: "What does RGB stand for?",
                5: "What function inserts a value for a custom property?"}

function_answers = {1: "attr()",
              2: "true",
              3: "false",
              4: "red green blue",
              5: "var()"}

function_hints = {1: "What's shorten version of attribute",
                  2: "You've got a 50/50 chance",
                  3: "Is that what max means?",
                  4: "There's definitely a red in there somewhere",
                  5: "Shortened word for variable..(remember the brackets)"}
