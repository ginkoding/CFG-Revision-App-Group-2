cs_questions = {1: "What does CSS stand for?",
                2: "Which tags in a HTML file would you refer to an external style sheet?",
                3: "How do you insert a comma into a CSS file?",
                4: "What property is used to change the background colour?",
                5: "What property controls text size?"}

cs_answers = {1: "cascading style sheets",
              2: "head",
              3: "/* */",
              4: "background-color",
              5: "font-size"}

cs_hints = {1: "It's not standard",
            2: "..., shoulders, knees and toes",
            3: "Stars in their eyes",
            4: "Just a hyphen in the middle",
            5: "Another word for text-size"}
