class_questions = {1: "A CSS class is an attribute used to define a group of HTML elements \n"
                      "in order to apply unique styling and formatting? true or false",
                2: "CSS classes can be added to; paragraph, title, headers. true or false",
                3: "Only one class can be applied to an element. true or false",
                4: "What's is the difference between class and ID?",
                5: "Which selector selects all elements with a specific class attribute?"}

class_answers = {1: "true",
              2: "true",
              3: "false",
              4: "ids are unique",
              5: "class selector"}

class_hints = {1: "How is class used?",
                  2: "You've got a 50/50 chance",
                  3: "Can there be only 1?",
                  4: "Do class names have to different?",
                  5: "Obvious when you think about it"}
