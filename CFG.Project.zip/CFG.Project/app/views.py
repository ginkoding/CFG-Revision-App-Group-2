from app import app

from flask import render_template, request, redirect

from app.css_questions import cs_questions
from app.css_questions import cs_hints
from app.css_questions import cs_answers

from app.css_function_questions import function_questions
from app.css_function_questions import function_hints
from app.css_function_questions import function_answers

from app.css_classes_questions import class_questions
from app.css_classes_questions import class_hints
from app.css_classes_questions import class_answers



@app.route('/')
@app.route('/quiz-menu')
def quiz_menu():
    return render_template("public/quiz_menu.html")

# CSS Basic Routes

@app.route("/css-basics")
def css_basics():
    questions = cs_questions
    hints = cs_hints

    return render_template("/public/css_basics.html", questions=questions, hints=hints)

@app.route("/css-basics-question-2")
def css_basics_question_2():
    questions = cs_questions
    hints = cs_hints

    return render_template("/public/css_basics_question_2.html", questions=questions, hints=hints)

@app.route("/css-basics-question-3")
def css_basics_question_3():
    questions = cs_questions
    hints = cs_hints

    return render_template("/public/css_basics_question_3.html", questions=questions, hints=hints)

@app.route("/css-basics-question-4")
def css_basics_question_4():
    questions = cs_questions
    hints = cs_hints

    return render_template("/public/css_basics_question_4.html", questions=questions, hints=hints)

# CSS Functions

@app.route("/css-functions")
def css_functions():
    questions = function_questions
    hints = function_hints

    return render_template("/public/css_functions.html", questions=questions, hints=hints)

@app.route("/css-functions-2")
def css_functions_2():
    questions = function_questions
    hints = function_hints

    return render_template("/public/css_functions_2.html", questions=questions, hints=hints)

@app.route("/css-functions-3")
def css_functions_3():
    questions = function_questions
    hints = function_hints

    return render_template("/public/css_functions_3.html", questions=questions, hints=hints)

@app.route("/css-functions-4")
def css_functions_4():
    questions = function_questions
    hints = function_hints

    return render_template("/public/css_functions_4.html", questions=questions, hints=hints)

# CSS Class

@app.route("/css-classes")
def css_classes():
    questions = class_questions
    hints = class_hints

    return render_template("/public/css_classes.html", questions=questions, hints=hints)

@app.route("/css-classes-2")
def css_classes_2():
    questions = class_questions
    hints = class_hints

    return render_template("/public/css_classes_2.html", questions=questions, hints=hints)

@app.route("/css-classes-3")
def css_classes_3():
    questions = class_questions
    hints = class_hints

    return render_template("/public/css_classes_3.html", questions=questions, hints=hints)

@app.route("/css-classes-4")
def css_classes_4():
    questions = class_questions
    hints = class_hints

    return render_template("/public/css_classes_4.html", questions=questions, hints=hints)
