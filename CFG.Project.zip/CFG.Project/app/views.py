from app import app

from flask import render_template, request, redirect

from app.css_questions import cs_questions
from app.css_questions import cs_hints
from app.css_questions import cs_answers


@app.route('/')
@app.route('/quiz-menu')
def quiz_menu():
    return render_template("public/quiz_menu.html")

# CSS Basic Routes

@app.route("/css-basics")
def css_basics():
    questions = cs_questions
    hints = cs_hints

    return render_template("/public/css_basics.html", questions=questions, hints=hints)

@app.route("/css-basics-question-2")
def css_basics_question_2():
    questions = cs_questions
    hints = cs_hints

    return render_template("/public/css_basics_question_2.html", questions=questions, hints=hints)

@app.route("/css-basics-question-3")
def css_basics_question_3():
    questions = cs_questions
    hints = cs_hints

    return render_template("/public/css_basics_question_3.html", questions=questions, hints=hints)

@app.route("/css-basics-question-4")
def css_basics_question_4():
    questions = cs_questions
    hints = cs_hints

    return render_template("/public/css_basics_question_4.html", questions=questions, hints=hints)

# CSS Functions

@app.route("/css-basics")
def css_basics():
    questions = cs_questions
    hints = cs_hints

    return render_template("/public/css_basics.html", questions=questions, hints=hints)

@app.route("/css-basics-question-2")
def css_basics_question_2():
    questions = cs_questions
    hints = cs_hints

    return render_template("/public/css_basics_question_2.html", questions=questions, hints=hints)

@app.route("/css-basics-question-3")
def css_basics_question_3():
    questions = cs_questions
    hints = cs_hints

    return render_template("/public/css_basics_question_3.html", questions=questions, hints=hints)

@app.route("/css-basics-question-4")
def css_basics_question_4():
    questions = cs_questions
    hints = cs_hints

    return render_template("/public/css_basics_question_4.html", questions=questions, hints=hints)
